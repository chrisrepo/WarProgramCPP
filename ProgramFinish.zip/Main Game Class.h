//
//  Main Game Class.h
//  War Program
//
//  Created by Chris on 1/23/14.
//  Copyright (c) 2014 The Casual Programmer. All rights reserved.
//

#ifndef __War_Program__Main_Game_Class__
#define __War_Program__Main_Game_Class__

#include <iostream>
#endif /* defined(__War_Program__Main_Game_Class__) */
